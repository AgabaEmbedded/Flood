# venezia-high-waters

Script to clean and aggregate official Venezia water level data from 1983 to 2015

The original data has been taken from [Centro Previsioni e Segnalazioni Maree](http://www.comune.venezia.it/archivio/25419)

The resulting dataset has been uploaded to [Kaggle](https://www.kaggle.com/lbronchal/venezia)

